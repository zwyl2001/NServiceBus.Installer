﻿using System;
using NServiceBus;
using NServiceBus.Saga;
using VideoStore.Messages.Commands;
using VideoStore.Messages.Events;

namespace VideoStore.CustomerRelations
{
    public class ProcessOrderCrSaga : Saga<ProcessOrderCrSaga.OrderData>,
        IAmStartedByMessages<OrderPlaced>,
        IHandleMessages<CancelOrder>,
        IHandleTimeouts<ProcessOrderCrSaga.BuyersRemorseIsOver>
    {
        public void Handle(OrderPlaced message)
        {
            Data.OrderNumber = message.OrderNumber;
            Data.VideoIds = message.VideoIds;
            Data.ClientId = message.ClientId;

            RequestUtcTimeout<ProcessOrderCrSaga.BuyersRemorseIsOver>(TimeSpan.FromSeconds(20),
                new BuyersRemorseIsOver());

            Console.Out.WriteLine("Starting cool down period for order #{0}.", Data.OrderNumber);
        }

        public void Timeout(BuyersRemorseIsOver state)
        {
            //Bus.Publish<OrderAccepted>(e =>
            //{
            //    e.OrderNumber = Data.OrderNumber;
            //    e.VideoIds = Data.VideoIds;
            //    e.ClientId = Data.ClientId;
            //});

            MarkAsComplete();

            Console.Out.WriteLine("Cooling down period for order #{0} has elapsed.", Data.OrderNumber);
        }

        public class BuyersRemorseIsOver
        {
        }

        public class OrderData : ISagaEntity
        {
            public Guid Id { get; set; }
            public string Originator { get; set; }
            public string OriginalMessageId { get; set; }
            public int OrderNumber { get; set; }
            public string[] VideoIds { get; set; }
            public string ClientId { get; set; }
        }

        public void Handle(CancelOrder message)
        {
            throw new NotImplementedException();
        }
    }
}