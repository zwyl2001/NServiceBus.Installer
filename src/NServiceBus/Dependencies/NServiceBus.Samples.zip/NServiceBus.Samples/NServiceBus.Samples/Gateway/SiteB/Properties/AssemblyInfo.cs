﻿using System.Reflection;

[assembly: AssemblyTitle("SiteB")]
[assembly: AssemblyProduct("SiteB")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
