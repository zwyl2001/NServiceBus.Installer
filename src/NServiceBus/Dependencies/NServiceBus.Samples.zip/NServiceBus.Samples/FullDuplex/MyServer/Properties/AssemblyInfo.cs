﻿using System.Reflection;

[assembly: AssemblyTitle("MyServer")]
[assembly: AssemblyProduct("MyServer")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
