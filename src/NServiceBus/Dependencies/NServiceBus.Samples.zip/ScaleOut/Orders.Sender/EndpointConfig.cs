﻿using NServiceBus;

namespace Orders.Sender
{
    class EndpointConfig : IConfigureThisEndpoint, AsA_Server {}
}
