﻿using System.Reflection;

[assembly: AssemblyTitle("VideoStore.DownloadVideos")]
[assembly: AssemblyProduct("VideoStore.DownloadVideos")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
