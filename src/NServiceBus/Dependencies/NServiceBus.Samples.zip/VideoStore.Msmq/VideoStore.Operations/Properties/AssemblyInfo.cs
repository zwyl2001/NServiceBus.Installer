﻿using System.Reflection;

[assembly: AssemblyTitle("MyRequestResponseEndpoint")]
[assembly: AssemblyProduct("MyRequestResponseEndpoint")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
