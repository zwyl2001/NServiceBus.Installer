﻿using System.Reflection;

[assembly: AssemblyTitle("VideoStore.CustomerRelations")]
[assembly: AssemblyProduct("VideoStore.CustomerRelations")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
