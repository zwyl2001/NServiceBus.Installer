﻿using System.Reflection;

[assembly: AssemblyTitle("MyServer.Tests")]
[assembly: AssemblyProduct("MyServer.Tests")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
