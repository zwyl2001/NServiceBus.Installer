﻿using System.Reflection;

[assembly: AssemblyTitle("MyMessages")]
[assembly: AssemblyProduct("MyMessages")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
