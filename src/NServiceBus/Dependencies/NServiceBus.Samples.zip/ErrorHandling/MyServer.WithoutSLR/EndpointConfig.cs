﻿using NServiceBus;

namespace MyServerNoSLR
{
    public class EndpointConfig : IConfigureThisEndpoint, AsA_Server { }
}
