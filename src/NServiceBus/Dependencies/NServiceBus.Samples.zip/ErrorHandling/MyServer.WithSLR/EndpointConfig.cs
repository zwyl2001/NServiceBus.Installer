﻿using NServiceBus;

namespace MyServerWithSLR
{
    public class EndpointConfig : IConfigureThisEndpoint, AsA_Server { }
}
